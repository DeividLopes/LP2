﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[10];
            double[] Preco = new double[10];

            string auxiliar=" ";
            double faturamento = 0;
            int[] Qtd = new int[10];

            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade do produto" + (i + 1).ToString(),


                      "Entrada de Dados");
                while (true)
                {
                    auxiliar = Interaction.InputBox("Digite o preço:" + (i + 1), "Entrada dos Preços");

                    if (!double.TryParse(auxiliar, out Preco[i]))
                        MessageBox.Show("Preço inválido!");
                    else
                    {
                        if (Preco[i] <= 0)
                            MessageBox.Show("Preço não pode ser <=0");
                        else
                        {
                            faturamento += Qtd[i] * Preco[i];
                            break;
                        }
                    }
                }
            }
            MessageBox.Show(faturamento.ToString());


        }
    }
}
