﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[7];
            int[] N = new int[7];
            string auxiliar = "";
            string auxiliar2 = "";

            for (var i = 0; i < 7; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome" + (i + 1).ToString());
                auxiliar2 = auxiliar;
                auxiliar = auxiliar.Replace(" ", "");
                lstbxUm.Items.Add("O nome " + auxiliar2 + " tem " + auxiliar.Length + " Caracteres");
                
                
            }


        }
    }
}
