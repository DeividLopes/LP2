﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Atividade_9
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList();
            Lista.Add("Ana");
            Lista.Add("Débora");
            Lista.Add("Fátima");
            Lista.Add("João");
            Lista.Add("Janete");
            Lista.Add("Otavio");
            Lista.Add("Marcelo");
            Lista.Add("Pedro");
            Lista.Add("Thais");
            Lista.Remove("Otavio");

            foreach (var item in Lista)
            {
                MessageBox.Show(item.ToString());
            }


        }
    }
}
