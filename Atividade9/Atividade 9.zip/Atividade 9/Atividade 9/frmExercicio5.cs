﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string auxiliar = "";
            double media = 0;
            double[,] notas = new double[20, 3];

            for (var i = 0; i < 20; i++)
            {
                media = 0;
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota" + (j + 1).ToString() + "do aluno" + (i + 1).ToString(), "entrada de dados");

                    if (!double.TryParse(auxiliar, out notas[i,j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }                      
                    else
                    {
                        if  (notas[i, j] <= 0 || notas[i,j] > 10)
                            MessageBox.Show("A nota não pode ser menor que 0 ou maior que 10");
                        else
                        {
                            media = media + notas[i,j];
                        }
                    }
                }
                media = media / 3;
                MessageBox.Show("A media do aluno" + (i + 1).ToString() + "é " + media.ToString("N2"), "média");
            }
        }
    }
}
