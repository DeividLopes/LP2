﻿
namespace P0030482113017
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVrtificar = new System.Windows.Forms.Button();
            this.LstbxVenda = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVrtificar
            // 
            this.btnVrtificar.Location = new System.Drawing.Point(86, 170);
            this.btnVrtificar.Name = "btnVrtificar";
            this.btnVrtificar.Size = new System.Drawing.Size(119, 54);
            this.btnVrtificar.TabIndex = 0;
            this.btnVrtificar.Text = "Verificar";
            this.btnVrtificar.UseVisualStyleBackColor = true;
            this.btnVrtificar.Click += new System.EventHandler(this.btn_Click);
            // 
            // LstbxVenda
            // 
            this.LstbxVenda.FormattingEnabled = true;
            this.LstbxVenda.ItemHeight = 15;
            this.LstbxVenda.Location = new System.Drawing.Point(555, 8);
            this.LstbxVenda.Name = "LstbxVenda";
            this.LstbxVenda.Size = new System.Drawing.Size(233, 334);
            this.LstbxVenda.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LstbxVenda);
            this.Controls.Add(this.btnVrtificar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVrtificar;
        private System.Windows.Forms.ListBox LstbxVenda;
    }
}

