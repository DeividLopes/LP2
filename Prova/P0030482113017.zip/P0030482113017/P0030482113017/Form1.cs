﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482113017
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            double[,] Valores = new double[7, 4];

            double soma = 0;
            double somaT = 0;
            double vlr = 0;

            string auxiliar = "";
      
            int[] teste = new int[10];

            for (var j = 0; j < 7; j++)
            {
                soma = 0;
                for (int i = 0; i < 4; i++)
                {
                    auxiliar = Interaction.InputBox("Semana " + (i + 1).ToString(), "Mês" + (j + 1));
                    double.TryParse(auxiliar, out vlr);
                    LstbxVenda.Items.Add("Total do mes " + (j + 1) + "semana" + (i + 1) + ":" + vlr.ToString("c"));
                    if (!double.TryParse(auxiliar, out Valores[j, i]))
                    {
                        j--;
                    }
                    else
                    {
                        if (Valores[j, i] <= 0)
                            MessageBox.Show("O valornão pode ser menor que 0");
                        else
                        {
                            soma = soma + Valores[j, i];
                            somaT = somaT + Valores[j, i];
                        }
                    }
                    
                }
                
                LstbxVenda.Items.Add("Total do mes" + soma.ToString("c"));

            }
            LstbxVenda.Items.Add("A soma de todos os meses é de " + somaT.ToString("c"));
        }
    }
}
