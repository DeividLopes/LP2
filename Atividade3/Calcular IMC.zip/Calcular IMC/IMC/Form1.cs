﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnIMC_Click(object sender, EventArgs e)
        {
            
            double Altura, Peso;

            if ((double.TryParse(mskbxAltura.Text, out Altura)) &&
            (double.TryParse(mskbxPeso.Text, out Peso)))
            {


                double Resultado;
                Resultado = Peso / Math.Pow(Altura, 2);
                Resultado = Math.Round(Resultado, 1);
                txtResultado.Text = Resultado.ToString("N2");
                

                //Magreza
                if (Resultado<18.5)
                {
                    MessageBox.Show("Magreza " + "\n\nObesidade Grau 0");
                }

                //Normal
                if (Resultado >= 18.5 && Resultado <=24.90)
                {
                    MessageBox.Show("Normal " + "\n\nObesidade Grau 0");
                }

                //Sobrepeso
                if (Resultado >= 25 && Resultado <=29.9)
                {
                    MessageBox.Show("Sobrepeso " + "\n\nObesidade Grau I");
                }

                //Obesidade
                if (Resultado >= 30 && Resultado <= 39.9)
                {
                    MessageBox.Show("Obesidade " + "\n\nObesidade Grau II");
                }

                //Obesidade Grave
                if (Resultado >40)
                {
                    MessageBox.Show("Obesidade Grave " + "\n\nObesidade Grau III");
                }

            }
            else
            {
                MessageBox.Show("Valores invalidos");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
