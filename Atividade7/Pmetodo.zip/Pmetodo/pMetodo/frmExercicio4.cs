﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodo
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int i=0;
            int soma = 0;
            string texto = rtxtTexto.Text;
            int z=0;
            


            for (i=0;i<=rtxtTexto.Text.Length-1;i++)
            {
                char x = texto[z];
                z = z + 1;
                if(Char.IsNumber(x))
                soma = soma +1;
            }
            
            
            MessageBox.Show(soma.ToString());
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            char[] vetor = rtxtTexto.Text.ToCharArray();
            
            string Vrtor = rtxtTexto.Text;
            int Cordenada = 0;


            while(rtxtTexto.Text.Length < rtxtTexto.Text.Length)
            {

                if ( char.IsWhiteSpace(' '))
                {

                    break;
                    
                }

            }
            MessageBox.Show(Cordenada.ToString());

        }

        private void btnLetras_Click(object sender, EventArgs e)
        {

            int soma = 0;

            char[] vetor = rtxtTexto.Text.ToCharArray();

            foreach (char c in vetor)
            {
                if(char.IsLetter(c))
                {
                    soma = soma + 1;
                }
            }
            MessageBox.Show(soma.ToString());





        }






        }
    }
    

