﻿
namespace Atividade8
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtFrase1 = new System.Windows.Forms.RichTextBox();
            this.btnPalindromo = new System.Windows.Forms.Button();
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtxtFrase1
            // 
            this.rtxtFrase1.Location = new System.Drawing.Point(55, 23);
            this.rtxtFrase1.MaxLength = 50;
            this.rtxtFrase1.Name = "rtxtFrase1";
            this.rtxtFrase1.Size = new System.Drawing.Size(443, 96);
            this.rtxtFrase1.TabIndex = 8;
            this.rtxtFrase1.Text = "";
            // 
            // btnPalindromo
            // 
            this.btnPalindromo.Location = new System.Drawing.Point(144, 146);
            this.btnPalindromo.Name = "btnPalindromo";
            this.btnPalindromo.Size = new System.Drawing.Size(232, 23);
            this.btnPalindromo.TabIndex = 7;
            this.btnPalindromo.Text = "Verificar se é Palíndromo";
            this.btnPalindromo.UseVisualStyleBackColor = true;
            this.btnPalindromo.Click += new System.EventHandler(this.btnPalindromo_Click);
            // 
            // lblNumero1
            // 
            this.lblNumero1.AutoSize = true;
            this.lblNumero1.Location = new System.Drawing.Point(15, 26);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(34, 15);
            this.lblNumero1.TabIndex = 6;
            this.lblNumero1.Text = "Frase";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtxtFrase1);
            this.Controls.Add(this.btnPalindromo);
            this.Controls.Add(this.lblNumero1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtFrase1;
        private System.Windows.Forms.Button btnPalindromo;
        private System.Windows.Forms.Label lblNumero1;
    }
}