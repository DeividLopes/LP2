﻿
namespace Atividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtRich = new System.Windows.Forms.RichTextBox();
            this.btnInsere2 = new System.Windows.Forms.Button();
            this.btnInsere1 = new System.Windows.Forms.Button();
            this.rtxttexto = new System.Windows.Forms.Button();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtxtRich
            // 
            this.rtxtRich.Location = new System.Drawing.Point(138, 23);
            this.rtxtRich.MaxLength = 100;
            this.rtxtRich.Name = "rtxtRich";
            this.rtxtRich.Size = new System.Drawing.Size(518, 96);
            this.rtxtRich.TabIndex = 12;
            this.rtxtRich.Text = "";
            // 
            // btnInsere2
            // 
            this.btnInsere2.Location = new System.Drawing.Point(565, 152);
            this.btnInsere2.Name = "btnInsere2";
            this.btnInsere2.Size = new System.Drawing.Size(188, 23);
            this.btnInsere2.TabIndex = 11;
            this.btnInsere2.Text = "Conta letras sequencias iguais";
            this.btnInsere2.UseVisualStyleBackColor = true;
            this.btnInsere2.Click += new System.EventHandler(this.btnInsere2_Click);
            // 
            // btnInsere1
            // 
            this.btnInsere1.Location = new System.Drawing.Point(302, 152);
            this.btnInsere1.Name = "btnInsere1";
            this.btnInsere1.Size = new System.Drawing.Size(245, 23);
            this.btnInsere1.TabIndex = 10;
            this.btnInsere1.Text = "Conta letras R";
            this.btnInsere1.UseVisualStyleBackColor = true;
            this.btnInsere1.Click += new System.EventHandler(this.btnInsere1_Click);
            // 
            // rtxttexto
            // 
            this.rtxttexto.Location = new System.Drawing.Point(72, 152);
            this.rtxttexto.Name = "rtxttexto";
            this.rtxttexto.Size = new System.Drawing.Size(209, 23);
            this.rtxttexto.TabIndex = 9;
            this.rtxttexto.Text = "Quantidade de espaços em branco ";
            this.rtxttexto.UseVisualStyleBackColor = true;
            this.rtxttexto.Click += new System.EventHandler(this.rtxttexto_Click);
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(98, 26);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(34, 15);
            this.lblPalavra1.TabIndex = 8;
            this.lblPalavra1.Text = "Frase";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtxtRich);
            this.Controls.Add(this.btnInsere2);
            this.Controls.Add(this.btnInsere1);
            this.Controls.Add(this.rtxttexto);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtRich;
        private System.Windows.Forms.Button btnInsere2;
        private System.Windows.Forms.Button btnInsere1;
        private System.Windows.Forms.Button rtxttexto;
        private System.Windows.Forms.Label lblPalavra1;
    }
}