﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string s = rtxtFrase1.Text;

            char[] arr = s.ToCharArray();

            Array.Reverse(arr);

            s = "";
            foreach (char c in arr)
            {
                s = s + c.ToString();
            }

            s.Replace(" ", "");


            if (s.ToUpper() == rtxtFrase1.Text.ToUpper().Replace(" ", "")) ;
            {
                MessageBox.Show("Palindromo");
            }
        }
    }
}
