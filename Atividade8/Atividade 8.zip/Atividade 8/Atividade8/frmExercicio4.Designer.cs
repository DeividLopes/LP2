﻿
namespace Atividade8
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtGratficação = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtProdução = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.ckbxVolante = new System.Windows.Forms.CheckBox();
            this.ckbxFreio = new System.Windows.Forms.CheckBox();
            this.ckbxEmbreagem = new System.Windows.Forms.CheckBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(619, 297);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(156, 23);
            this.button2.TabIndex = 37;
            this.button2.Text = "Limpar informações";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(254, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 36;
            this.label5.Text = "Salário Bruto";
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Enabled = false;
            this.txtSalarioBruto.Location = new System.Drawing.Point(335, 251);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(100, 23);
            this.txtSalarioBruto.TabIndex = 35;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(254, 297);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 23);
            this.button1.TabIndex = 34;
            this.button1.Text = "Calcular salário bruto";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtGratficação
            // 
            this.txtGratficação.Location = new System.Drawing.Point(88, 238);
            this.txtGratficação.Name = "txtGratficação";
            this.txtGratficação.Size = new System.Drawing.Size(100, 23);
            this.txtGratficação.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 15);
            this.label4.TabIndex = 32;
            this.label4.Text = "Gratificação";
            // 
            // txtProdução
            // 
            this.txtProdução.Location = new System.Drawing.Point(88, 189);
            this.txtProdução.Name = "txtProdução";
            this.txtProdução.Size = new System.Drawing.Size(100, 23);
            this.txtProdução.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 15);
            this.label3.TabIndex = 30;
            this.label3.Text = "Produção";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 15);
            this.label2.TabIndex = 29;
            this.label2.Text = "Maricula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(88, 144);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 23);
            this.txtMatricula.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(254, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 15);
            this.label1.TabIndex = 27;
            this.label1.Text = "Salário base do cargo";
            // 
            // txtSalario
            // 
            this.txtSalario.Enabled = false;
            this.txtSalario.Location = new System.Drawing.Point(254, 82);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(119, 23);
            this.txtSalario.TabIndex = 26;
            // 
            // ckbxVolante
            // 
            this.ckbxVolante.AutoSize = true;
            this.ckbxVolante.Location = new System.Drawing.Point(88, 107);
            this.ckbxVolante.Name = "ckbxVolante";
            this.ckbxVolante.Size = new System.Drawing.Size(131, 19);
            this.ckbxVolante.TabIndex = 25;
            this.ckbxVolante.Text = "Produtor de volante";
            this.ckbxVolante.UseVisualStyleBackColor = true;
            // 
            // ckbxFreio
            // 
            this.ckbxFreio.AutoSize = true;
            this.ckbxFreio.Location = new System.Drawing.Point(88, 82);
            this.ckbxFreio.Name = "ckbxFreio";
            this.ckbxFreio.Size = new System.Drawing.Size(116, 19);
            this.ckbxFreio.TabIndex = 24;
            this.ckbxFreio.Text = "Produtor de freio";
            this.ckbxFreio.UseVisualStyleBackColor = true;
            // 
            // ckbxEmbreagem
            // 
            this.ckbxEmbreagem.AutoSize = true;
            this.ckbxEmbreagem.Location = new System.Drawing.Point(89, 57);
            this.ckbxEmbreagem.Name = "ckbxEmbreagem";
            this.ckbxEmbreagem.Size = new System.Drawing.Size(156, 19);
            this.ckbxEmbreagem.TabIndex = 23;
            this.ckbxEmbreagem.Text = "Produtor de embreagem";
            this.ckbxEmbreagem.UseVisualStyleBackColor = true;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(12, 57);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(39, 15);
            this.lblCargo.TabIndex = 22;
            this.lblCargo.Text = "Cargo";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(88, 18);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 23);
            this.txtNome.TabIndex = 21;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Location = new System.Drawing.Point(12, 21);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(40, 15);
            this.lblTexto.TabIndex = 20;
            this.lblTexto.Text = "Nome";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtGratficação);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtProdução);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.ckbxVolante);
            this.Controls.Add(this.ckbxFreio);
            this.Controls.Add(this.ckbxEmbreagem);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtGratficação;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtProdução;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.CheckBox ckbxVolante;
        private System.Windows.Forms.CheckBox ckbxFreio;
        private System.Windows.Forms.CheckBox ckbxEmbreagem;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblTexto;
    }
}