﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void rtxttexto_Click(object sender, EventArgs e)
        {
            char[] Array = rtxtRich.Text.ToCharArray();
            int i = 0;
            int contador = 0;

            for (i = 0; i < rtxtRich.Text.Length; i++)
            {
                if (Array[i] == ' ')
                {
                    contador++;
                }
            }
            MessageBox.Show("O texto tem " + contador.ToString() + " espaços");
        }

        private void btnInsere1_Click(object sender, EventArgs e)
        {
            char[] Array = rtxtRich.Text.ToCharArray();
            int i = 0;
            int contador = 0;

            while (i < rtxtRich.Text.Length)
            {
                if (Array[i] == 'R' || Array[i] == 'r')
                {
                    contador++;
                }
                i++;
            }
            MessageBox.Show("O texto tem " + contador.ToString() + " caracteres R");
        }

        private void btnInsere2_Click(object sender, EventArgs e)
        {
            char[] Array = rtxtRich.Text.ToCharArray();
            int i = 0;
            int contador = 0;

            for (i = 1; i < rtxtRich.Text.Length - 1; i++)
            {

                if (Array[i] == Array[i + 1])
                {
                    contador++;
                }
            }
            MessageBox.Show(contador.ToString());
        }
    }
}
