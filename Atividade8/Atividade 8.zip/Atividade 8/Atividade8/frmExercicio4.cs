﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double Salario = 0, SalarioBruto = 0, Gratificacao = 0;
            double A = 0, B = 0, C = 0, D = 0;
            double Producao;

            if (ckbxEmbreagem.Checked && ckbxFreio.Checked || ckbxVolante.Checked)
            {
                MessageBox.Show("Selecione somente um cargo");
                txtSalarioBruto.Text = " ";
                txtSalario.Text = " ";
            }
            else
            {
                //Tests the valor of  A B C D  according to produção
                if ((double.TryParse(txtProdução.Text, out Producao)))
                {
                    if (Producao >= 100)
                    {
                        B = 1;
                    }
                    if (Producao < 100)
                    {
                        B = 0;
                    }
                    if (Producao >= 120)
                    {
                        C = 1;
                    }
                    if (Producao < 120)
                    {
                        C = 0;
                    }
                    if (Producao >= 150)
                    {
                        D = 1;
                    }
                    if (Producao < 150)
                    {
                        D = 0;
                    }
                }
                // Test end

                //Tests if the costumer is Produtor de embreagem



                if ((double.TryParse(txtGratficação.Text, out Gratificacao))) ;
                {
                    if (ckbxEmbreagem.Checked)
                    {
                        Salario = 2000;
                    }
                    if (ckbxFreio.Checked)
                    {
                        Salario = 3000;
                    }
                    if (ckbxVolante.Checked)
                    {
                        Salario = 5000;
                    }
                    A = Salario;
                    txtSalario.Text = Salario.ToString();
                    SalarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;

                    if (SalarioBruto <= 7000)
                    {
                        txtSalarioBruto.Text = SalarioBruto.ToString();
                    }

                    if (SalarioBruto > 7000)
                    {
                        if (SalarioBruto > 7000 && Producao >= 150 && Gratificacao > 0)
                        {
                            txtSalarioBruto.Text = SalarioBruto.ToString();
                        }
                        else
                        {
                            txtSalarioBruto.Text = Salario.ToString();
                        }
                    }
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtGratficação.Clear();
            txtNome.Clear();
            txtProdução.Clear();
            txtSalario.Clear();
            txtSalarioBruto.Clear();
            txtMatricula.Clear();
        }
    }
}
