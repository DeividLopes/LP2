﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Salário
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double SalarioBruto = 0;

            if(txtNome.Text=="")
                MessageBox.Show("Nome inválido");
            //INSS
            else if(double.TryParse(mskbxSalarioBruto.Text, out SalarioBruto))
            {
                //INSS
                if(SalarioBruto <=800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * SalarioBruto;
                }
               
                else if (SalarioBruto >=800.48 && SalarioBruto <=1050)
                {
                     txtAliquotaINSS.Text = "8.65%";
                     descontoINSS = 0.0865 * SalarioBruto;
                }

                else if (SalarioBruto >= 1050.01 && SalarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    descontoINSS = 0.09 * SalarioBruto;
                }
                else if (SalarioBruto >= 1400.78 && SalarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    descontoINSS = 0.11 * SalarioBruto;
                }
                else if (SalarioBruto >= 2801.56)
                {
                    txtAliquotaINSS.Text = "TETO";
                    descontoINSS = 308.17;
                }
                //IRPF
                if (SalarioBruto <1257.12)
                {
                    txtAliquotaIRPF.Text = "Isento";
                    descontoIRPF = 0;
                }
                else if (SalarioBruto >=1257.12 && SalarioBruto<=2512.08)
                {
                    txtAliquotaIRPF.Text = "15.00%";
                    descontoIRPF = 0.15 * SalarioBruto;
                }
                else if (SalarioBruto > 2512.08)
                {
                    txtAliquotaIRPF.Text = "27.50%";
                    descontoIRPF = 0.275 * SalarioBruto;
                }
                //Salário familia
                if(SalarioBruto<=435.52)
                {
                  salarioFamilia = Convert.ToDouble(cbxFilhos.SelectedItem.ToString()) * 22.33;
                    mskbxSalarioFamilia.Text = salarioFamilia.ToString();
                }
                if (SalarioBruto > 435.52 && SalarioBruto <=654.61)
                {
                    salarioFamilia = Convert.ToDouble(cbxFilhos.SelectedItem.ToString()) * 15.74;
                    mskbxSalarioFamilia.Text = salarioFamilia.ToString();
                }
                //Salário Liquido 
                if(SalarioBruto>0)
                {
                    salarioLiquido = SalarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    mskbxSalarioLiquido.Text = salarioLiquido.ToString("N2");
                }
                //LBL
                if(rbtnFeminino.Checked && ckbxCasado.Checked)
                {
                    lblMensagem.Text = lblMensagem.Text + " do salário da Sra" + txtNome.Text + "Que é casada\n";
                }
                else if(rbtnFeminino.Checked)
                {
                    lblMensagem.Text = lblMensagem.Text + "do salário da Sra " + txtNome.Text;
                }

                if (rbtnMasculino.Checked && ckbxCasado.Checked)
                {
                    lblMensagem.Text = lblMensagem.Text + " do salário do Sr\n " + txtNome.Text + ", que é casado\n";
                }
                else if (rbtnMasculino.Checked)
                {
                    lblMensagem.Text = lblMensagem.Text + "do salário do Sr " + txtNome.Text;
                }
                if(SalarioBruto>0)
                {
                    lblMensagem.Text =lblMensagem.Text + "E que tem " + cbxFilhos.SelectedItem.ToString()+" filhos são";
                }
               






            }



        }

        private void cbxFilhos_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxSalarioBruto.Clear();
            mskbxSalarioFamilia.Clear();
            mskbxSalarioLiquido.Clear();
            txtAliquotaINSS.Clear();
            txtAliquotaIRPF.Clear();
            txtNome.Clear();
            lblMensagem.Text = "Os descontos";
            
        }

        private void lblMensagem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxFilhos.SelectedIndex = 0;
        }
    }
}
