﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_básica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2;

            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
            (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                double Resultado;
                Resultado = Numero1 + Numero2;
                txtResultado.Text = Resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores invalidos");
            }

        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2;

            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
            (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                double Resultado;
                Resultado = Numero1 - Numero2;
                txtResultado.Text = Resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores invalidos");
            }
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2;

            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
            (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                double Resultado;
                Resultado = Numero1 * Numero2;
                txtResultado.Text = Resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores invalidos");
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2;


            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
            (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                double Resultado;
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString("N2");

                if (txtNumero2.Text == "0" || txtNumero1.Text == "0")
                {
                    txtResultado.Clear();
                    MessageBox.Show("Impossível dividir por 0");
                }
            }

            else
            {
                MessageBox.Show("Valores invalidos");
            }
            

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
