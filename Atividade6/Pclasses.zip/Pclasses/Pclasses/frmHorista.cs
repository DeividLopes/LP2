﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            // instanciando o objeto da classe horista
            Horista objHorista = new Horista();

            //set - atribui valores para o objeto
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);
            //get - imprime os valores do objeto
            MessageBox.Show("Nome:" + objHorista.NomeEmpregado +
            "\n" + "Matrícula:" + objHorista.Matricula + "\n" +
            "Tempo Trabalho (dias) :" + objHorista.TempoTrabalho().ToString()
            + "\n" + "Salário:" + objHorista.SalarioBruto().ToString("N2"));
        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }



